//! Optional, visible mouse steps beside an existing precise numeric field.
use egui::{Response, Ui};
use std::ops::RangeInclusive;

pub struct NumberStepperResponse {
    /// Retains the numeric field's focus/drag response; changed includes a step.
    pub response: Response,
    /// Each successful button click starts a separate editing gesture.
    pub stepped: bool,
}

/// Keep the caller's numeric editor intact and append two bounded step buttons.
/// Steps preserve fractional values. Showing an existing out-of-range value, or
/// clicking a disabled boundary button, never changes it. The caller continues
/// to own validation, edit transactions and numeric formatting.
pub fn number_stepper(
    ui: &mut Ui,
    value: &mut f64,
    step: f64,
    range: RangeInclusive<f64>,
    name: &str,
    field: impl FnOnce(&mut Ui, &mut f64) -> Response,
) -> NumberStepperResponse {
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = crate::tokens::SPACE_XS;
        // DragValue removes its prefix/suffix in text mode. Retain the measured
        // field width while it has focus so a second click still reaches the
        // editor instead of a step button that moved under the pointer.
        // Sibling horizontal rows share their persistent Ui id. Use the next
        // widget id so neighbouring fields cannot overwrite each other's size.
        let width_id = ui.next_auto_id().with("number_stepper_field_width");
        let previous = ui.data(|data| data.get_temp::<(egui::Id, f32)>(width_id));
        let original_width = ui.spacing().interact_size.x;
        if let Some((id, width)) = previous
            && ui.memory(|memory| memory.has_focus(id))
        {
            ui.spacing_mut().interact_size.x = original_width.max(width);
        }
        let mut response =
            field(ui, value).on_hover_text("Drag the value for fine adjustment; use −/+ to step");
        ui.spacing_mut().interact_size.x = original_width;
        if !response.has_focus() || previous.is_none() {
            ui.data_mut(|data| data.insert_temp(width_id, (response.id, response.rect.width())));
        }
        let mut stepped = false;
        for (symbol, direction, verb) in [("−", -1.0, "Decrease"), ("+", 1.0, "Increase")] {
            let next = *value + direction * step;
            let allowed = step.is_finite()
                && step > 0.0
                && next.is_finite()
                && next != *value
                && range.contains(&next);
            let button = ui
                .add_enabled(
                    allowed,
                    crate::button_widget(symbol).small().min_size(egui::vec2(
                        crate::tokens::COMPACT_HEIGHT,
                        crate::tokens::CONTROL_HEIGHT,
                    )),
                )
                .on_hover_text(format!("{verb} {name} by {step}"));
            button.widget_info(|| {
                egui::WidgetInfo::labeled(
                    egui::WidgetType::Button,
                    ui.is_enabled() && allowed,
                    format!("{verb} {name} by {step}"),
                )
            });
            if button.clicked() {
                *value = next;
                stepped = true;
                response.mark_changed();
            }
        }
        NumberStepperResponse { response, stepped }
    })
    .inner
}

//! Device failures stay distinct from plugin failures in the running app.
mod common;

use common::Harness;
use daw_core::{AudioData, Clip, Project};
use serde_json::{Value, json};
use std::time::{Duration, Instant};

fn ready(app: &mut Harness) -> Value {
    let deadline = Instant::now() + Duration::from_secs(15);
    loop {
        let state = app.inspect();
        if state["engine"]["playing"] == true && state["playback_loading"] == false {
            return state;
        }
        assert!(Instant::now() < deadline, "{state}");
        std::thread::sleep(Duration::from_millis(2));
    }
}

fn audible(app: &mut Harness) {
    let state = app.command(json!({"command":"pump_audio", "frames":512}));
    assert_eq!(state["engine"]["render_errors"], 0);
    assert_eq!(state["engine"]["underruns"], 0);
    assert!(
        state["audio_output"]
            .as_array()
            .unwrap()
            .iter()
            .all(|frame| {
                (frame[0].as_f64().unwrap() - 0.4).abs() < 1e-6
                    && (frame[1].as_f64().unwrap() - 0.2).abs() < 1e-6
            })
    );
}

#[test]
fn playback_device_failure_keeps_backend_details_and_recovers_with_stop_and_play() {
    let mut app = Harness::with_virtual_audio(None, None);
    let wav = app.directory.path().join("source.wav");
    AudioData {
        sample_rate: 48_000,
        channels: 2,
        samples: (0..48_000).flat_map(|_| [0.4, 0.2]).collect(),
    }
    .write_wav(&wav)
    .unwrap();
    let mut project = Project::new();
    let id = project.add_audio_track("Playback only");
    project.track_mut(id).unwrap().gain = 1.0;
    project.track_mut(id).unwrap().clips.push(Clip::audio(
        "Sound",
        0.0,
        2.0,
        wav.to_string_lossy(),
    ));
    let path = app.directory.path().join("Output error.rill");
    project.save(&path).unwrap();
    app.command(json!({"command":"open", "path":path}));
    app.click("Window");
    app.click("Recording");
    // New audio tracks already select Mono 1; arm that visible default route.
    let armed = app.click("Arm recording");
    assert_eq!(
        armed["project"]["tracks"][0]["audio_input"],
        json!({"Mono":{"channel":0}})
    );
    assert!(
        armed["recording"]["armed"]
            .as_array()
            .unwrap()
            .contains(&json!(id))
    );
    app.key("Escape");
    app.click("Play");
    let initial = ready(&mut app);
    audible(&mut app);
    let failed = app.command(json!({"command":"output_error"}));
    assert_eq!(failed["engine"]["playing"], false);
    assert_eq!(failed["engine"]["output_failed"], true);
    assert_eq!(failed["engine"]["render_errors"], 0);
    assert!(
        failed["status"]
            .as_str()
            .unwrap()
            .contains("Audio output stream failed")
    );
    let shown = app.click("Details");
    let detail = shown["error_details"]["details"]
        .as_str()
        .unwrap()
        .to_owned();
    assert!(detail.contains("Virtual output disconnected"));
    assert!(detail.contains("Stop and Play"));
    assert!(!detail.contains("Plug-in/render"));
    assert!(!detail.contains("MIDI recording"));
    assert!(
        failed["visible_labels"]
            .as_array()
            .unwrap()
            .iter()
            .any(|label| label == "Audio setup…")
    );
    assert_eq!(app.click("Copy details")["clipboard_text"], detail);
    app.click("Close");
    app.click("Dismiss");
    let duplicate = app.command(json!({"command":"output_error"}));
    assert_eq!(
        duplicate["error"], false,
        "A latched device error must not reappear after dismissal"
    );
    assert_eq!(duplicate["engine"]["render_errors"], 0);
    let retry = app.click("Record");
    assert_eq!(retry["recording"]["phase"], "idle");
    assert_eq!(retry["engine"]["engine_id"], initial["engine"]["engine_id"]);
    assert_eq!(retry["engine"]["output_failed"], true);
    assert_eq!(retry["engine"]["playing"], false);
    assert!(retry["status"].as_str().unwrap().contains("Stop and Play"));
    let silent = app.command(json!({"command":"pump_audio", "frames":512}));
    assert!(
        silent["audio_output"]
            .as_array()
            .unwrap()
            .iter()
            .all(|frame| { frame[0].as_f64() == Some(0.0) && frame[1].as_f64() == Some(0.0) })
    );
    app.click("Dismiss");
    app.click("Stop");
    app.click("Play");
    let resumed = ready(&mut app);
    assert_ne!(
        initial["engine"]["engine_id"],
        resumed["engine"]["engine_id"]
    );
    assert_eq!(resumed["engine"]["output_failed"], false);
    audible(&mut app);
    app.click("Stop");
    app.quit();
}

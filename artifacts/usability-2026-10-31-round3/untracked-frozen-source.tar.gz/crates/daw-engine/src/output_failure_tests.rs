use super::*;

#[test]
fn output_device_failure_retains_backend_cause_once_without_plugin_or_midi_recording_errors() {
    let mut engine = AudioEngine::start_virtual_cancellable(
        &Project::new(),
        DeviceSettings::default(),
        Arc::new(AtomicBool::new(false)),
    )
    .unwrap();
    engine.set_playing(true);
    let error = cpal::Error::with_message(
        cpal::ErrorKind::DeviceNotAvailable,
        "Output Ω disconnected: driver code 42 🎧",
    );
    assert_eq!(
        crate::allocation_test_support::count_allocations(|| {
            for _ in 0..2048 {
                output_stream_failed(&engine.controls, &error);
            }
        }),
        0
    );
    let state = engine.snapshot();
    assert!(state.output_failed);
    assert!(!state.playing);
    assert_eq!(state.render_errors, 0);
    assert!(engine.take_render_error().is_none());
    assert!(engine.take_midi_error().is_none());
    let diagnostic = engine.take_input_error().unwrap();
    assert!(diagnostic.contains("Audio output stream failed"));
    assert!(diagnostic.contains("Output Ω disconnected: driver code 42 🎧"));
    assert!(diagnostic.contains("Stop and Play"));
    assert!(engine.take_input_error().is_none());
    // A failed stream cannot be made healthy by merely setting playing=true,
    // including the engine-ready handoff racing an early device failure.
    engine.set_playing(true);
    assert!(!engine.snapshot().playing);
    output_stream_failed(&engine.controls, &error);
    assert!(engine.take_input_error().is_none());
    assert!(engine.take_midi_error().is_none());
    assert!(
        engine
            .pump_virtual(256)
            .unwrap()
            .iter()
            .all(|s| *s == [0.0; 2])
    );
}

#[test]
fn output_advisory_does_not_latch_or_stop_playback_but_a_real_fault_does() {
    let controls = Controls::new();
    controls.playing.store(true, Ordering::Release);
    for kind in [
        cpal::ErrorKind::RealtimeDenied,
        cpal::ErrorKind::DeviceChanged,
    ] {
        output_stream_failed(&controls, &cpal::Error::new(kind));
    }
    assert!(!controls.output_failed.load(Ordering::Acquire));
    assert!(controls.playing.load(Ordering::Acquire));
    output_stream_failed(&controls, &cpal::Error::new(cpal::ErrorKind::BackendError));
    assert!(controls.output_failed.load(Ordering::Acquire));
    assert!(!controls.playing.load(Ordering::Acquire));
    assert_eq!(controls.render_errors.load(Ordering::Relaxed), 0);
}

#[test]
fn unclassified_backend_and_other_errors_remain_fatal() {
    for kind in [
        cpal::ErrorKind::BackendError,
        cpal::ErrorKind::Other,
        cpal::ErrorKind::StreamInvalidated,
    ] {
        let controls = Controls::new();
        controls.playing.store(true, Ordering::Release);
        output_stream_failed(&controls, &cpal::Error::new(kind));
        assert!(controls.output_failed.load(Ordering::Acquire));
        assert!(!controls.playing.load(Ordering::Acquire));
        assert_eq!(controls.render_errors.load(Ordering::Relaxed), 0);
    }
}

#[test]
fn output_failure_between_transport_check_and_publication_cannot_resurrect_playback() {
    let engine = AudioEngine::start_virtual_cancellable(
        &Project::new(),
        DeviceSettings::default(),
        Arc::new(AtomicBool::new(false)),
    )
    .unwrap();
    let (entered, wait_for_check) = mpsc::channel();
    let (release, released) = mpsc::channel();
    PLAYING_PUBLICATION_TEST_GATE.with(|gate| *gate.borrow_mut() = Some((entered, released)));
    let controls = Arc::clone(&engine.controls);
    let failure = thread::spawn(move || {
        wait_for_check.recv_timeout(Duration::from_secs(5)).unwrap();
        output_stream_failed(
            &controls,
            &cpal::Error::new(cpal::ErrorKind::DeviceNotAvailable),
        );
        release.send(()).unwrap();
    });
    engine.set_playing(true);
    failure.join().unwrap();
    assert!(engine.snapshot().output_failed);
    assert!(!engine.snapshot().playing);
    assert!(!engine.controls.playing.load(Ordering::Acquire));
}

#[test]
fn failed_output_rejects_audio_midi_and_audition_without_clearing_its_cause() {
    let directory = tempfile::tempdir().unwrap();
    let mut project = Project::new();
    let audio = project.add_audio_track("Audio input");
    let midi = project.add_midi_track("MIDI input");
    let mut engine = AudioEngine::start_virtual_cancellable(
        &project,
        DeviceSettings::default(),
        Arc::new(AtomicBool::new(false)),
    )
    .unwrap();
    engine
        .configure_input(
            &project,
            InputSettings {
                device_name: None,
                routes: vec![InputRoute {
                    track: audio,
                    channels: daw_core::AudioInputChannels::Mono { channel: 0 },
                    monitor: true,
                }],
            },
        )
        .unwrap();
    engine.fail_virtual_output().unwrap();
    // Reopening MIDI inputs is allowed, but must not reopen the failed output.
    engine
        .configure_midi(
            &project,
            MidiSettings {
                port_id: Some("rill-virtual-midi".into()),
                routes: vec![MidiRoute {
                    track: midi,
                    channel: None,
                    monitor: true,
                }],
            },
        )
        .unwrap();
    assert!(engine.recording_snapshot().input_ready);
    assert!(engine.midi_snapshot().input_ready);
    for error in [
        engine
            .start_recording(RecordingConfig {
                directory: directory.path().join("takes"),
                tracks: vec![audio],
            })
            .unwrap_err(),
        engine.start_midi_recording(vec![midi]).unwrap_err(),
        engine.audition_note(Some((midi, 60, 100))).unwrap_err(),
    ] {
        assert!(error.to_string().contains("Stop and Play"));
    }
    assert!(!engine.recording_snapshot().active);
    assert!(!engine.recording_snapshot().preparing);
    assert!(!engine.midi_snapshot().active);
    assert!(!directory.path().join("takes").exists());
    assert!(
        engine
            .take_input_error()
            .unwrap()
            .contains("Virtual output disconnected")
    );
    assert!(engine.take_input_error().is_none());
    engine.audition_note(None).unwrap();
    assert!(
        engine
            .pump_virtual(256)
            .unwrap()
            .iter()
            .all(|frame| *frame == [0.0; 2])
    );
}

#[test]
fn terminal_callback_cannot_emit_queued_preview_or_stale_play_requests() {
    let controls = Controls::new();
    let queue = AudioQueue::new(256);
    for frame in 0..256 {
        queue.push([0.6, -0.2], frame as f64, 0);
    }
    output_stream_failed(
        &controls,
        &cpal::Error::new(cpal::ErrorKind::DeviceNotAvailable),
    );
    // A count-in/capture publication already in flight must not override the
    // terminal latch, even when the queue still contains real signal.
    controls.playing.store(true, Ordering::Release);
    controls.auditioning.store(true, Ordering::Release);
    let mut output = [1.0_f32; 512];
    assert_eq!(
        crate::allocation_test_support::count_allocations(|| {
            fill_output(&mut output, 2, &queue, &controls);
        }),
        0
    );
    assert!(output.iter().all(|sample| *sample == 0.0));
    assert_eq!(
        queue.free(),
        0,
        "Failed stream must not consume the queued audio"
    );
    assert_eq!(controls.consumed_frames.load(Ordering::Relaxed), 0);
    assert!(!controls.playing.load(Ordering::Acquire));
    assert!(!controls.auditioning.load(Ordering::Acquire));
}
